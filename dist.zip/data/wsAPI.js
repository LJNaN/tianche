const wsAPI = `ws://128.168.11.111:8090/MOC/OHTC/SendData/${new Date() * 1}`
// const wsAPI = `ws://192.168.150.133:8090/MOC/OHTC/SendData/${new Date() * 1}`

window.wsAPI = wsAPI