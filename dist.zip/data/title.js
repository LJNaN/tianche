const title = 'FAB2 Wafer Sort AMHS搬送可视化'
window.title = title